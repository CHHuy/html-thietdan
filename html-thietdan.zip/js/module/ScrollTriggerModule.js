export default function ScrollTriggerModule() {

}
