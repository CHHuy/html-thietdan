export default function Select2Module() {
  $(document).ready(function () {
    $('.select-from').select2();
  });
}
