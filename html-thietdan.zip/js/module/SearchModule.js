export default function SearchModule(number) {

}